#ifndef MATRIX_H
#define MATRIX_H
#include <iostream>
using namespace std;
class Matrix
{
    public:
          int row,col;
          int *data;
    public:
        Matrix();
        // Matrix(row,col,data,mat);
        Matrix(const Matrix& other);
        Matrix (int row, int col, int num[]);
        friend ostream& operator<< (ostream& out,const Matrix& mat);
        friend istream& operator>> (istream& in, Matrix& mat);
        //friend void setRow(int r);

        // Student #1 with the smallest ID (e.g., 20170080)
// All these operations return a new matrix with the calculation result

 Matrix operator+  ( Matrix mat2); // Add if same dimensions
 Matrix operator-  ( Matrix mat2); // Sub if same dimensions
Matrix operator*  ( Matrix mat2); // Multi if col1 == row2
Matrix operator+  ( int scalar);  // Add a scalar
 Matrix operator-  ( int scalar);  // Subtract a scalar
 Matrix operator*  ( int scalar);  // Multiple by scalar

// Student #2 with the middle ID (e.g., 20170082)
// The last operator >> takes an istream and a matrix and return the
// the same istream so it is possible to cascade input like
// cin >> matrix1 >> matrix2 << endl;
 Matrix operator+= ( Matrix mat2); // mat1 changes & return
// new matrix with the sum
 Matrix operator-= ( Matrix mat2); // mat1 changes + return new					     // matrix with difference
 Matrix operator+= ( int scalar);
 Matrix  operator-= ( int scalar);   // change mat & return new matrix
 void   operator++ ();   	// Add 1 to each element ++mat
 void   operator-- ();    	// Sub 1 from each element --mat
//
// Input matrix like this (dim 2 x 3) cin >> 2 3 4 6 8 9 12 123
// and return istream to allow cascading input

//Student #3 with the biggest ID (e.g., 20170089)
//
// Print matrix  as follows (2 x 3)			4	 6 	  8
// and return ostream to cascade printing	9	12  	123
 bool   operator== ( Matrix mat2);	// True if identical
 bool   operator!= ( Matrix mat2); 	// True if not same
 bool   isSquare   ();  // True if square matrix
 bool   isSymetric ();  // True if square and symmetric
 bool   isIdentity ();  // True if square and identity
 Matrix transpose();
  bool   isSquarewithoutcout   ();
};

#endif // MATRIX_H
