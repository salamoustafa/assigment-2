#include "Matrix.h"
#include <iostream>
using namespace std;
Matrix::Matrix()
{
   cout<<"Welcome to the constructor "; //ctor
}
Matrix:: Matrix(int row, int col, int num[])
{
    this->row = row;
    this->col = col;
    this->data = new int [row * col];
    for (int i = 0; i < row * col; i++){
        data [i] = num [i];
    }
}

Matrix::Matrix(const Matrix& other)
{
    row = other.row;
    col = other.col;
    data = new int [row * col];
    for (int i = 0; i < row * col; i++)
        data [i] =other.data [i]; //copy ctor
}

//the code which print the Matrix
ostream& operator<< (ostream& out,const Matrix& mat){
   for (int i = 0; i < mat.row ; i++){
           for (int j = 0; j <  mat.col; j++){
               out<<mat.data[i*mat.col+j]<<" ";
        }
        out<<endl;
   }
   return out;
}
istream& operator>> (istream& in, Matrix& mat){

   for (int i = 0; i < mat.row ; i++){
           for (int j = 0; j <  mat.col; j++){
               in>>mat.data[i*mat.col+j];
        }
   }
   return in;
}
 // change mat & return new matrix
Matrix Matrix::operator+(Matrix mat2){
    int data3[row*col];
    Matrix mat3(row,col,data3);
    for (int i = 0; i < row * col; i++){

mat3.data[i]=this->data[i]+mat2.data[i];
    }
    return mat3;
}
 // Subtract two matrix
Matrix Matrix::operator-(Matrix mat2){
    int data3[row*col];
    Matrix mat3(row,col,data3);
    for (int i = 0; i < row * col; i++){
          mat3.data[i]=this->data[i]- mat2.data[i];
    }
    return mat3;
}
//Multiply two matrix
Matrix Matrix::operator*(Matrix mat2){
  if(col==mat2.row)
    {
        int sum=0;
        int data4 [row*mat2.col];
        Matrix mat3 (row,mat2.col,data4);
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < row; j++)
            {
                for (int k = 0; k < col; k++)
                {
                    sum=sum+(data[i*col+k]*mat2.data[k*mat2.col+j]);

                }
                mat3.data[i*mat2.col+j]=sum;
                sum=0;
            }
        }
        return mat3;
    }
    else
        cout<<" Invalid Input ";

}
 // Add a scalar to matrix
Matrix Matrix:: operator+  ( int scalar){
int data4[row*col];
Matrix mat3(row,col,data4);
for (int i = 0; i < row * col; i++){
          mat3.data[i]=this->data[i]+ scalar;
    }
    return mat3;

}
 // Subtract a scalar to matrix
Matrix Matrix:: operator- ( int scalar){
int data4[row*col];
Matrix mat3(row,col,data4);
for (int i = 0; i < row * col; i++){
          mat3.data[i]=this->data[i]-scalar;
    }
    return mat3;

}
 // Multiply scalar to matrix
Matrix Matrix:: operator* ( int scalar){
int data4[row*col];
Matrix mat3(row,col,data4);
for (int i = 0; i < row * col; i++){
          mat3.data[i]=this->data[i]*scalar;
    }
    return mat3;
}
// mat1 changes & return as we sum the two matrix and put it in mat1
Matrix Matrix:: operator+= ( Matrix mat2){
for (int i = 0; i < row * col; i++){
          data[i]=this->data[i]+ mat2.data[i];
    }
    return *this;
 }
 // mat1 changes + return new and matrix with difference
Matrix Matrix:: operator-= ( Matrix mat2){
for (int i = 0; i < row * col; i++){
          data[i]=this->data[i]- mat2.data[i];
    }
    return *this;
}
Matrix Matrix:: operator+= ( int scalar){
for (int i = 0; i < row * col; i++){
          data[i]=this->data[i]+ scalar;
    }
    return *this;
}
Matrix Matrix:: operator-= ( int scalar){
for (int i = 0; i < row * col; i++){
          data[i]-= scalar;
    }
    return *this;
}
// Add 1 to each element ++mat
void Matrix::   operator++ (){
for (int i = 0; i < row * col; i++){
          data[i]++;
    }
}
// subtract 1 from each element ++mat
 void Matrix::   operator-- (){
 for (int i = 0; i < row * col; i++){
          data[i]--;
    }
 }

bool Matrix::  operator== ( Matrix mat2){
    int x=0;
    if (row==mat2.row && col==mat2.col){
        for (int j=0; j<(row*col); j++){
            if (data[j]==mat2.data[j]){
                    x=1;
            }else {cout <<"Error! The Two Matrix are different\n";
                cout <<"Error! The Two Matrix are not Identical\n";
                x=2;
                return 0;
                break;}
            }
    }else {cout <<"Error! The Two Matrix has not the same rows and col\nThe Two Matrix are not Identity\n";
    x=2;
    return 0;}
    if (x==1){
        cout<<"Yes! The Two Matrix are Identity\n";
        return 1;}
}
///////////////////////////////////////////////////////////
bool Matrix::  operator!= ( Matrix mat2){
int x=0;
    if (row==mat2.row && col==mat2.col){
        for (int j=0; j<(row*col); j++){
            if (data[j]!=mat2.data[j]){
                    x=2;
            }else cout <<"Yes! The Two Matrix are not the same\n";
            x=3;
            return 1;
            break;
            }
    }else {cout <<"Yes! The Two Matrix are not the same\n";
    x=3;
    return 1;}
    if (x==2){
        cout<<"Error! The Two Matrix are the same\n";
        return 0;}
}
///////////////////////////////////////////////////////////
bool Matrix::  isSquare   (){
    if (col==row){
        cout<<"The Matrix is square\n";
        return 1;
    }else {cout<<"The Matrix is not square\n";
    return 0;}
}
/////////////////////////////////////////////////////////
 bool Matrix::  isSquarewithoutcout   (){
 if (col==row){
        return 1;
    }else {
    return 0;}}


///////////////////////////////////////////////////////////
bool Matrix::   isSymetric (){
    int t=5;
//------------------------------------
    int x=0;
    int arr2d[row][col];
    for (int i=0;i<row ; i++){
        for (int j=0 ;j<col ; j++){
            arr2d[i][j]=data [x];
            if (x<(row*col))x++;}}

//------------------------------------
    int m=isSquarewithoutcout();
    if (m=1){
    for (int i=0;i<row ; i++){
        for (int j=0 ;j<col ; j++){
            if (arr2d[i][j]==arr2d[j][i]){
                t=5;
            }else {cout<< "Matrix is not Symetric\n";
            return 0;
                break;}
        }}
    }else {cout<<"Error: Can not be symetric as the row is not equal cols \n";
    t=4;
    return 0;}
    if (t=5){
        cout<<"The Matrix is symetric: \n";
        return 1;}}
///////////////////////////////////////////////////////////
bool  Matrix:: isIdentity (){
    int a=0 , b=0;
    int p=isSquarewithoutcout();
    if(p=1){
//------------------------------------------
    int x=0,a=0,b=0;
    int arr2d[row][col];
    for (int i=0;i<row ; i++){
        for (int j=0 ;j<col ; j++){
            arr2d[i][j]=data [x];
            if (x<(row*col))x++;}}
//------------------------------------------
    for (int i=0;i<row ; i++){
        for (int j=0 ;j<col ; j++){
            if ((i==j&&arr2d[i][j]==1)||(i!=j&&arr2d[i][j]==0)){
                a=1;
            }
//            else if(i!=j&&arr2d[i][j]==0){
//                b=1;}
            else {cout<<"Sorry! The Matrix is not Identity:\n";
                a=2;
                return 0;
                break;}
        }}
        if(a==1){cout<<"The Matrix is Identity:\n";
        return 1;
    }
    }
    else{cout<<"can not be as the row not equal cols:\n";
            return 0;}


}
/////////////////////////////////////////////////////////////////////

Matrix Matrix:: transpose(){
    int x=0;
    int arrtd[row][col];
    for (int i=0;i<row ; i++){
        for (int j=0 ;j<col ; j++){
            arrtd[i][j]=data[x];
            if (x<(row*col)){x++;}}}
//------------transfering data------------------
    int  array2d  [col][row];
    for (int i=0;i<col ; i++){
        for (int j=0 ;j<row ; j++){
            array2d[i][j]=arrtd[j][i];}}
//-----------back to 1d-------------------------
   // Matrix nwmat;
    int nwcol=row;
    int nwrow=col;
    int nwdata[nwcol*nwrow];
    int y=0;
    for (int i=0;i<nwrow ; i++){
        for (int j=0 ;j<nwcol ; j++){
            nwdata[y]=array2d[i][j];
            if (y<(row*col)){y++;}}}
    for (int a=0 ;a<(nwrow*nwcol);a++){cout<<nwdata[a]<<" ";}
//-------------couting--------------------------
Matrix nwmat(nwrow,nwcol,nwdata);
return nwmat;
}
