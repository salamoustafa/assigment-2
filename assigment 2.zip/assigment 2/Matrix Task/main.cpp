#include <iostream>
#include "Matrix.h"
using namespace std;


//istream& operator>> (istream& in, Matrix& mat);
int main()
{

   // int row,col;
   // cout<<"enter the row = ";
    //cin>>row;
    // cout<<"enter the col = ";
    //cin>>col;
    int data1[]={1,2,3,4,5,5};
    int data2[]={1,2,3,4,5,6};
    Matrix mat1(3,2,data1);
    Matrix mat2(3,2,data2);
    Matrix mat3=mat2;
   // mat2=mat1;
    cout<<mat3<<endl;;
    //cin>>mat1;
   //mat1+=mat2;
   //    mat1==mat2;
  // mat1=mat1.transpose();
 // mat1.isSquare();
   //cout<<endl;
   cout<<mat1+mat2;
    return 0;
}

