#include <iostream>
#include <string>
using namespace std;

class Person
{
    public:
        /* Constructors */
        Person () ;
        Person ( string theName ) ;
        Person ( const Person& theObject ) ;

        /* Accessor */
        string getName () const ;

        /* Operator overloads
        Person& operator =(const Person& rtSide);
        friend istream& operator >>(istream& inStream, Person& personObject);
        friend ostream& operator <<(ostream& outStream,
                                             const Person& personObject); */
    private:
        /* Variable declaration */
        string name ;
};

/* Every vehicle has an owner, manufacturer, and a quantity of cylinders */
class Vehicle
{
    public:
        /* Constructors */
        Vehicle () ;
        Vehicle ( string manufacturer ) ;
        Vehicle( string manufacturer ,  int numCylinders ) ;
        Vehicle( string manufacturer ,  int numCylinders , Person owner ) ;
        Vehicle( const Vehicle& theObject ) ;

        /* Accessors */
        string getManufacturer () const ;
        int getNumCylinders () const ;
        string getOwner () const ;

        /* Operator overloads
        Vehicle& operator =(const Vehicle& rtSide);*/

        /* Variable declaration */
        Person owner ;
    protected:
        /* Variable declaration */
        string manufacturer;
        int numCylinders;
};

/* Every truck is a vehicle and has a tow and load capacity */

class Truck :  public Vehicle
{
    private:
        double load_capacity ;
        int towing_capacity ;

    public:
        Truck() ;
        Truck ( string manufacturer , int numCylinders , Person owner ,  double load_capacity , int towing_capacity ) ;
        double get_load_capacity () const ;
        int get_towing_capacity () const ;


};
//-------------------------------------------Main---------------------------------
int  main ()
{
    Vehicle v ( "BMW" ) ;
    Person zizo ( "zizo" ) ;
    Truck t1 ( "Bmw" , 4 , zizo , 2.0 , 11 ) ;
   cout << t1.getNumCylinders () << endl ;
   Truck t2 = t1 ;
    cout << t2.getOwner () << endl ;
    cout << t2.getManufacturer ()  << endl ;
    cout << t2.get_load_capacity () << endl ;
    cout <<  t2.get_towing_capacity() << endl ;

    return 0;
}

/* Constructors for Person class */
/* Default person has no name */
Person :: Person ()
{
    name = "" ;
}

Person :: Person ( string theName )
{
    name = theName ;
}

Person :: Person ( const Person& theObject )
{
    this -> name = theObject.getName () ;
}

/* Accessors for Person class */
string Person :: getName () const
{
    return name ;
}


//-------------------------------------------Vehicle------------------------------------------------

/* Constructors for Vehicle class */
Vehicle :: Vehicle()
{
    Person defaultOwner("") ;
    this -> manufacturer = "" ;
    this -> numCylinders = 0 ;
    this -> owner = defaultOwner ;
}

Vehicle :: Vehicle ( string manufacturer )
{
    Person defaultOwner("") ;

    this -> manufacturer = manufacturer ;
    this -> numCylinders = 0 ;
    this -> owner = defaultOwner ;
}

Vehicle :: Vehicle ( string manufacturer ,  int numCylinders )
{
    Person defaultOwner("") ;

    this -> manufacturer = manufacturer ;
    this -> numCylinders = numCylinders ;
    this -> owner = defaultOwner ;
}

Vehicle :: Vehicle ( string manufacturer ,  int numCylinders ,  Person owner )
{
    this -> manufacturer = manufacturer ;
    this -> numCylinders = numCylinders ;
    this -> owner = owner ;
}

Vehicle :: Vehicle ( const Vehicle& theObject )
{
    this -> manufacturer = theObject.manufacturer ;
    this -> numCylinders = theObject.numCylinders ;
    this -> owner = theObject.owner ;
}

/* Accessors for Vehicle class */
string Vehicle :: getManufacturer ()  const
{
    return manufacturer ;
}

int Vehicle :: getNumCylinders ()  const
{
    return numCylinders ;
}
 string Vehicle :: getOwner () const
{
    return owner.getName () ;
}

/* Operator overloads for Vehicle class */



//-------------------------------------------Truck------------------------------------------------

Truck :: Truck()
{
    this -> numCylinders = 0 ;
    this -> manufacturer = "" ;
    this -> load_capacity = 0.0 ;
    Person defaultOwner("") ;

}

Truck :: Truck(string manufacturer , int  numCylinders , Person owner , double load_capacity , int towing_capacity )
{
    this -> manufacturer = manufacturer ;
    this -> numCylinders = numCylinders ;
    this -> load_capacity = load_capacity ;
    this -> towing_capacity = towing_capacity ;
    this -> owner = owner ;


}

double Truck :: get_load_capacity ()  const
{
    return ( load_capacity ) ;
}
int Truck :: get_towing_capacity () const
{
    return (towing_capacity) ;
}
