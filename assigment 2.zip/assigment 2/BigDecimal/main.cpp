#include <iostream>
#include "BigDecimal.h"
using namespace std;
int main()
{
    BigDecimal num1 ("600000");
    BigDecimal num2 ("700");
    BigDecimal num3("20000");
    BigDecimal num4("20");
    cout<<"sum is"<<endl;
    cout<<num1+num2<<endl<<endl;;
    cout<<"Diffrenece is "<<endl;
    cout<<num3-num4<<endl<<endl;;
    return 0;
}
