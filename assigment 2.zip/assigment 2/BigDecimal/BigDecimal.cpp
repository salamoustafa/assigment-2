#include "BigDecimal.h"
#include <iostream>
#include <string>
using namespace std;
BigDecimal::BigDecimal()
{
    num1="";
    //ctor
}
BigDecimal::BigDecimal(string num1)
{
    this-> num1=num1;

    //ctor
}

BigDecimal BigDecimal:: CallException (BigDecimal &num2){
    int diff=0;
    if(num1.size()==num2.num1.size())
    {
        if(num1[0]<num2.num1[0])
        {
            string temp ;
            temp=num1;
            num1=num2.num1;
            num2.num1=temp;
            diff=num1.size()-num2.num1.size();
            for(int i=num1.size()-1; i>=0; i--)
            {
                num1[i]=int(num1[i]-48);
                num2.num1[i]=int(num2.num1[i]-48);
                if(num1[i]<num2.num1[i])
                {
                    num1[i]=num1[i]+10;
                    num1[i-1]=num1[i-1]-1;
                    num2.num1[i]=num1[i]-num2.num1[i];
                    num2.num1[i]=char(num2.num1[i]+48);
                }
                if(num1[i]>=num2.num1[i])
                {
                    num2.num1[i]=(num1[i]-num2.num1[i]);
                    num2.num1[i]=char(num2.num1[i]+48);
                }
            }
            return num2;
        }
        else
        {
            for(int i=num1.size()-1; i>=0; i--)
            {
                num1[i]=int(num1[i]-48);
                num2.num1[i]=int(num2.num1[i]-48);
                if(num1[i]<num2.num1[i])
                {
                    num1[i]=num1[i]+10;
                    num1[i-1]=num1[i-1]-1;
                    num2.num1[i]=num1[i]-num2.num1[i];
                    num2.num1[i]=char(num2.num1[i]+48);
                }
                if(num1[i]>=num2.num1[i])
                {
                    num2.num1[i]=(num1[i]-num2.num1[i]);
                    num2.num1[i]=char(num2.num1[i]+48);
                }
            }
            cout<<"-";
            return num2;

        }
    }
}
BigDecimal BigDecimal:: CallFunctionSubtract (BigDecimal &num2)
{
    int diff=0,counter=0;
    if(num1.size()>num2.num1.size())
    {
        diff=num1.size()-num2.num1.size();
        while(counter<diff)
        {
            num2.num1='0'+num2.num1;
            counter++;
        }
        for(int i=num1.size()-1; i>=0; i--)
        {
            num1[i]=int(num1[i]-48);
            num2.num1[i]=int(num2.num1[i]-48);
            if(num1[i]<num2.num1[i])
            {
                num1[i]=num1[i]+10;
                num1[i-1]=num1[i-1]-1;
                num2.num1[i]=num1[i]-num2.num1[i];
                num2.num1[i]=char(num2.num1[i]+48);
            }
            if(num1[i]>=num2.num1[i])
            {
                num2.num1[i]=(num1[i]-num2.num1[i]);
                num2.num1[i]=char(num2.num1[i]+48);
            }

        }
        num2.num1='-'+num2.num1;;
        return num2;
    }
    if(num1.size()<num2.num1.size())
    {
        string temp ;
        temp=num1;
        num1=num2.num1;
        num2.num1=temp;
        diff=num1.size()-num2.num1.size();
        while(counter<diff)
        {
            num2.num1='0'+num2.num1;
            counter++;
        }
        for(int i=num1.size()-1; i>=0; i--)
        {
            num1[i]=int(num1[i]-48);
            num2.num1[i]=int(num2.num1[i]-48);
            if(num1[i]<num2.num1[i])
            {
                num1[i]=num1[i]+10;
                num1[i-1]=num1[i-1]-1;
                num2.num1[i]=num1[i]-num2.num1[i];
                num2.num1[i]=char(num2.num1[i]+48);
            }
            if(num1[i]>=num2.num1[i])
            {
                num2.num1[i]=(num1[i]-num2.num1[i]);
                num2.num1[i]=char(num2.num1[i]+48);
            }
        }
        return num2;
    }

    if(num1.size()==num2.num1.size())
    {
        if(num1[0]<num2.num1[0])
        {
            string temp ;
            temp=num1;
            num1=num2.num1;
            num2.num1=temp;
            diff=num1.size()-num2.num1.size();
            for(int i=num1.size()-1; i>=0; i--)
            {
                num1[i]=int(num1[i]-48);
                num2.num1[i]=int(num2.num1[i]-48);
                if(num1[i]<num2.num1[i])
                {
                    num1[i]=num1[i]+10;
                    num1[i-1]=num1[i-1]-1;
                    num2.num1[i]=num1[i]-num2.num1[i];
                    num2.num1[i]=char(num2.num1[i]+48);
                }
                if(num1[i]>=num2.num1[i])
                {
                    num2.num1[i]=(num1[i]-num2.num1[i]);
                    num2.num1[i]=char(num2.num1[i]+48);
                }
            }
            cout<<"-";
            return num2;
        }
        else
        {
            for(int i=num1.size()-1; i>=0; i--)
            {
                num1[i]=int(num1[i]-48);
                num2.num1[i]=int(num2.num1[i]-48);
                if(num1[i]<num2.num1[i])
                {
                    num1[i]=num1[i]+10;
                    num1[i-1]=num1[i-1]-1;
                    num2.num1[i]=num1[i]-num2.num1[i];
                    num2.num1[i]=char(num2.num1[i]+48);
                }
                if(num1[i]>=num2.num1[i])
                {
                    num2.num1[i]=(num1[i]-num2.num1[i]);
                    num2.num1[i]=char(num2.num1[i]+48);
                }
            }
            return num2;

        }
    }
}

BigDecimal BigDecimal:: CallFunctionSum (BigDecimal &num2)
{
    int diff=0,counter=0;
    if(num1.size()>num2.num1.size())
    {
        diff=num1.size()-num2.num1.size();
        while(counter<diff)
        {
            num2.num1='0'+num2.num1;
            counter++;
        }
    }
    if(num2.num1.size()>num1.size())
    {
        diff=num2.num1.size()-num1.size();
        while(counter<diff)
        {
            num1='0'+num1;
            counter++;
        }
    }
    for(int i=num1.size()-1; i>=0; i--)
    {
        num1[i]=int(num1[i]-48);
        num2.num1[i]=int(num2.num1[i]-48);
        if(num1[i]+num2.num1[i]>=10)
        {
            if(i==0)
            {
                num2.num1[i]=num1[i]+num2.num1[i];
                num2.num1[i]-=10;
                cout<<"1";
            }
            else
            {
                num2.num1[i]=(num1[i]+num2.num1[i])-10;
                num1[i-1]+=1;
                num2.num1[i]=char(num2.num1[i]+48);
            }
        }
        else
        {
            num2.num1[i]=num1[i]+num2.num1[i];
            num2.num1[i]=char(num2.num1[i]+48);
        }
    }
    return num2;
    if(num1.size()==num2.num1.size())
    {
    for(int i=num1.size()-1; i>=0; i--)
    {
        num1[i]=int(num1[i]-48);
        num2.num1[i]=int(num2.num1[i]-48);
        if(num1[i]+num2.num1[i]>=10)
        {
            if(i==0)
            {
                num2.num1[i]=num1[i]+num2.num1[i];
                num2.num1[i]-=10;
                 num2.num1[i]='1'+num2.num1[i];
            }
            else
            {
                num2.num1[i]=(num1[i]+num2.num1[i])-10;
                num1[i-1]+=1;
                num2.num1[i]=char(num2.num1[i]+48);
            }
        }
        else
        {
            num2.num1[i]=num1[i]+num2.num1[i];
            num2.num1[i]=char(num2.num1[i]+48);
        }
    }
    return num2;
}
}
BigDecimal BigDecimal:: operator+ (BigDecimal &num2)
{
    bool c=true;
    int diff=0,counter=0;
    if(num1[0]=='-' && num2.num1[0]!='-' ){
      num2.num1= '0';
      c=false;
        return num2;
    }
    if(c==true){
    if(num1[0]=='-' && num2.num1[0]!='-')
    {
        num1.erase(num1.begin()+ 0) ;
        if(num1.size()==num2.num1.size()){
        CallException(num2);
        }
        else{CallFunctionSubtract(num2);}
       //cout<<'-';
        return num2;
        }
        }
    if(num1[0]=='-' && num2.num1[0]=='-')
    {

    num1.erase(num1.begin()+ 0) ;
    num2.num1.erase(num2.num1.begin()+0);
    CallFunctionSum(num2);
    return num2;

    }
      if(num1[0]!='-' && num2.num1[0]=='-')
    {

    //num1.erase(num1.begin()+ 0) ;
    num2.num1.erase(num2.num1.begin()+0);
    if(num2.num1.size()>num1.size()){
        cout<<"-";
    CallFunctionSubtract(num2);
    }
    if(num2.num1.size()<num1.size()){
       // cout<<"-";
          CallFunctionSubtract(num2);
  num2.num1.erase(num2.num1.begin()+0);

    }
    return num2;

    }
    if(num1.size()>num2.num1.size())
    {
        diff=num1.size()-num2.num1.size();
        while(counter<diff)
        {
            num2.num1='0'+num2.num1;
            counter++;

        }
    }
    if(num2.num1.size()>num1.size())
    {
        diff=num2.num1.size()-num1.size();
        while(counter<diff)
        {
            num1='0'+num1;
            counter++;
        }
    }
    for(int i=num1.size()-1; i>=0; i--)
    {
        num1[i]=int(num1[i]-48);
        num2.num1[i]=int(num2.num1[i]-48);
        if(num1[i]+num2.num1[i]>=10)
        {
            if(i==0)
            {
                num2.num1[i]=num1[i]+num2.num1[i];
                num2.num1[i]-=10;
                cout<<"1";
            }
            else
            {
                num2.num1[i]=(num1[i]+num2.num1[i])-10;
                num1[i-1]+=1;
                num2.num1[i]=char(num2.num1[i]+48);
            }
        }
        else
        {
            num2.num1[i]=num1[i]+num2.num1[i];
            num2.num1[i]=char(num2.num1[i]+48);
        }

    }
    return num2;

}
BigDecimal BigDecimal:: operator- (BigDecimal &num2)
{
    if(num2.num1 == num1){
        num2.num1= '0';
        return num2;
    }
    int diff=0,counter=0;
/*
     if(num1[0]!='-' && num2.num1[0]!='-')
    {
          CallFunctionSubtract(num2);
          return num2;
    }
*/
    if(num1[0]=='-' && num2.num1[0]!='-')
    {
        num1.erase(num1.begin()+ 0) ;
        CallFunctionSum(num2);
        cout<<'-';
        return num2;
    }
    if(num1[0]=='-' && num2.num1[0]=='-')
    {
        num1.erase(num1.begin()+ 0) ;
        num2.num1.erase(num2.num1.begin()+ 0) ;
        CallFunctionSubtract(num2);
        return num2;
    }
    if(num1[0]!='-' && num2.num1[0]=='-')
    {
        num2.num1.erase(num2.num1.begin()+ 0) ;
        CallFunctionSum(num2);
        return num2;
    }
    if(num1.size()>num2.num1.size())
    {
        diff=num1.size()-num2.num1.size();
        while(counter<diff)
        {
            num2.num1='0'+num2.num1;
            counter++;
        }
        for(int i=num1.size()-1; i>=0; i--)
        {
            num1[i]=int(num1[i]-48);
            num2.num1[i]=int(num2.num1[i]-48);
            if(num1[i]<num2.num1[i])
            {
                num1[i]=num1[i]+10;
                num1[i-1]=num1[i-1]-1;
                num2.num1[i]=num1[i]-num2.num1[i];
                num2.num1[i]=char(num2.num1[i]+48);
            }
            if(num1[i]>=num2.num1[i])
            {
                num2.num1[i]=(num1[i]-num2.num1[i]);
                num2.num1[i]=char(num2.num1[i]+48);
            }
        }
        return num2;
    }
    if(num1.size()<num2.num1.size())
    {
        string temp ;
        temp=num1;
        num1=num2.num1;
        num2.num1=temp;
        diff=num1.size()-num2.num1.size();
        while(counter<diff)
        {
            num2.num1='0'+num2.num1;
            counter++;
        }
        for(int i=num1.size()-1; i>=0; i--)
        {
            num1[i]=int(num1[i]-48);
            num2.num1[i]=int(num2.num1[i]-48);
            if(num1[i]<num2.num1[i])
            {
                num1[i]=num1[i]+10;
                num1[i-1]=num1[i-1]-1;
                num2.num1[i]=num1[i]-num2.num1[i];
                num2.num1[i]=char(num2.num1[i]+48);
            }
            if(num1[i]>=num2.num1[i])
            {
                num2.num1[i]=(num1[i]-num2.num1[i]);
                num2.num1[i]=char(num2.num1[i]+48);
            }
        }
        cout<<"-";
        return num2;
    }
    if(num1.size()==num2.num1.size())
    {
        if(num1[0]<num2.num1[0])
        {
            string temp ;
            temp=num1;
            num1=num2.num1;
            num2.num1=temp;
            diff=num1.size()-num2.num1.size();
            while(counter<diff)
            {
                num2.num1='0'+num2.num1;
                counter++;
            }
            for(int i=num1.size()-1; i>=0; i--)
            {
                num1[i]=int(num1[i]-48);
                num2.num1[i]=int(num2.num1[i]-48);
                if(num1[i]<num2.num1[i])
                {
                    num1[i]=num1[i]+10;
                    num1[i-1]=num1[i-1]-1;
                    num2.num1[i]=num1[i]-num2.num1[i];
                    num2.num1[i]=char(num2.num1[i]+48);
                }
                if(num1[i]>=num2.num1[i])
                {
                    num2.num1[i]=(num1[i]-num2.num1[i]);
                    num2.num1[i]=char(num2.num1[i]+48);
                }
            }
            cout<<"-";
            return num2;
        }
        else
        {
            for(int i=num1.size()-1; i>=0; i--)
            {
                num1[i]=int(num1[i]-48);
                num2.num1[i]=int(num2.num1[i]-48);
                if(num1[i]<num2.num1[i])
                {
                    num1[i]=num1[i]+10;
                    num1[i-1]=num1[i-1]-1;
                    num2.num1[i]=num1[i]-num2.num1[i];
                    num2.num1[i]=char(num2.num1[i]+48);
                }
                if(num1[i]>=num2.num1[i])
                {
                    num2.num1[i]=(num1[i]-num2.num1[i]);
                    num2.num1[i]=char(num2.num1[i]+48);
                }
            }
            return num2;

        }
    }
}
ostream&operator<<(ostream&out,const BigDecimal &big)
{
    for(int i=0; i<big.num1.size(); i++)
    {
        out<<big.num1[i];

    }
    return out;
}
