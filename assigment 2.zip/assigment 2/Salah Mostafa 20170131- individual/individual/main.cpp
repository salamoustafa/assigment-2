#include <iostream>
#include <sstream>
#include <string>
using namespace std;
class nextLabel
{
    int counter;
    string name;
    string word;

public:
    nextLabel()
    {
        name="";
        counter=0;
    }
    nextLabel(string name,int counter)
    {
        this->name=name;
        this->counter=counter;
    }
    string  nextlabel()
    {
        stringstream ss;
        ss<<counter++;
        word=ss.str();
        return name +" "+ word;
    }
};
int main()
{
    nextLabel n1("figure",1);
    nextLabel n2("p",0);
    cout<<"figure numbers : ";
    for(int i=0; i<3; i++)
    {
        if(i>0)
            cout<<" , ";
        cout<<n1.nextlabel();
    }
    cout<<endl<<"Point numbers : ";
    for(int i=0; i<3; i++)
    {
        if(i>0)
            cout<<" , ";
        cout<<n2.nextlabel();
    }
    cout<<endl<<"More figures : ";
    for(int i=0; i<3; i++)
    {
        if(i>0)
            cout<<" , ";
        cout<<n1.nextlabel();
    }
    cout<<endl;
    return 0;
}
